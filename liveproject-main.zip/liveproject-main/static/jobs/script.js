// Job Data (Can be replaced with API data later)
const jobDetails = {
    title: "Senior UX Designer",
    company: "TechCorp",
    location: "San Francisco, CA • Remote",
    salary: "$120K-$150K",
    jobType: "Full-time",
    postedTime: "Posted 2 days ago",
    applicationDeadline: "Application Deadline: 30 days",
    description: "TechCorp is seeking a Senior UX Designer to join our product team. In this role, you will lead the design of innovative digital experiences that delight our users and drive business growth.",
    responsibilities: [
        "Lead UX design for key product initiatives",
        "Create wireframes, prototypes, and high-fidelity designs",
        "Conduct user research and usability testing",
        "Collaborate with product managers and engineers",
        "Mentor junior designers and contribute to design system"
    ],
    requirements: [
        "5+ years of UX design experience",
        "Strong portfolio demonstrating user-centered design",
        "Proficiency in Figma, Sketch, and prototyping tools",
        "Experience with user research methodologies",
        "Excellent communication and collaboration skills"
    ],
    benefits: [
        "Competitive salary and equity package",
        "Comprehensive health, dental, and vision insurance",
        "Flexible remote work policy",
        "Professional development budget",
        "Generous PTO and parental leave"
    ],
    companyInfo: {
        name: "TechCorp",
        description: "TechCorp is a leading technology company specializing in innovative software solutions. With over 500 employees worldwide, we're on a mission to transform how people interact with technology."
    },
    similarJobs: [
        {
            company: "DesignHub",
            title: "UX/UI Designer",
            location: "New York, NY",
            salary: "$115K-$140K",
            workType: "Remote"
        },
        {
            company: "CreativeTech",
            title: "Product Designer",
            location: "Austin, TX",
            salary: "$115K-$145K",
            workType: "Hybrid"
        }
    ]
};

// Function to Populate Job Data
function populateJobDetails() {
    document.getElementById("job-title").innerText = jobDetails.title;
    document.getElementById("job-title-nav").innerText = jobDetails.title;
    document.getElementById("company-name").innerText = jobDetails.company;
    document.getElementById("location").innerText = jobDetails.location;
    document.getElementById("salary").innerText = jobDetails.salary;
    document.getElementById("job-type").innerText = jobDetails.jobType;
    document.getElementById("posted-time").innerText = jobDetails.postedTime;
    document.getElementById("application-deadline").innerText = jobDetails.applicationDeadline;
    document.getElementById("job-description").innerText = jobDetails.description;
    document.getElementById("company-info-name").innerText = jobDetails.companyInfo.name;
    document.getElementById("company-info-description").innerText = jobDetails.companyInfo.description;

    // Populate Responsibilities
    const responsibilitiesList = document.getElementById("responsibilities-list");
    jobDetails.responsibilities.forEach(responsibility => {
        const li = document.createElement("li");
        li.innerText = responsibility;
        responsibilitiesList.appendChild(li);
    });

    // Populate Requirements
    const requirementsList = document.getElementById("requirements-list");
    jobDetails.requirements.forEach(requirement => {
        const li = document.createElement("li");
        li.innerText = requirement;
        requirementsList.appendChild(li);
    });

    // Populate Benefits
    const benefitsList = document.getElementById("benefits-list");
    jobDetails.benefits.forEach(benefit => {
        const li = document.createElement("li");
        li.innerText = benefit;
        benefitsList.appendChild(li);
    });

    // Populate Similar Jobs
    const similarJobsContainer = document.getElementById("similar-jobs");
    jobDetails.similarJobs.forEach(job => {
        const jobDiv = document.createElement("div");
        jobDiv.classList.add("similar-job");
        jobDiv.innerHTML = `
            <h4>${job.company}</h4>
            <p>${job.title}</p>
            <p>${job.location} | ${job.salary} | ${job.workType}</p>
            <button>View Job</button>
        `;
        similarJobsContainer.appendChild(jobDiv);
    });
    
    // Check for saved mode preference
    if (localStorage.getItem("darkMode") === "enabled") {
        document.body.classList.add("dark-mode");
        document.querySelector(".toggle-mode").textContent = "Light Mode";
    }
}

// Toggle between dark and light mode
function toggleMode() {
    document.body.classList.toggle("dark-mode");
    
    // Update button text
    const button = document.querySelector(".toggle-mode");
    if (document.body.classList.contains("dark-mode")) {
        button.textContent = "Light Mode";
        // Save preference
        localStorage.setItem("darkMode", "enabled");
    } else {
        button.textContent = "Dark Mode";
        // Save preference
        localStorage.setItem("darkMode", "disabled");
    }
}

// Run the function on page load
window.onload = populateJobDetails;
